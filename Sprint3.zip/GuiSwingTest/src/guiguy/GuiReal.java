package guiguy;

import javax.swing.*;
import java.awt.*;

public class GuiReal {
    public static void main(String[] args) {
        // Create a JFrame (window)
        JFrame frame = new JFrame("Checkbox to Left");

        // Create a JPanel for the left side (containing a checkbox)
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS)); // Vertical layout

        // Create a checkbox
        JCheckBox checkBox = new JCheckBox("Checkbox");

        // Add the checkbox to the left panel
        leftPanel.add(checkBox);

        // Create a JPanel for the right side (containing the label)
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BorderLayout());

        // Create a JLabel to display text
        JLabel label = new JLabel("SOS Game");
        label.setHorizontalAlignment(JLabel.CENTER); // Center the text horizontally

        // Add the label to the right panel
        rightPanel.add(label, BorderLayout.NORTH);

        JPanel radioButtonsPanel = new JPanel();
        radioButtonsPanel.setLayout(new BoxLayout(radioButtonsPanel, BoxLayout.Y_AXIS));

        ButtonGroup buttonGroup = new ButtonGroup();
        JRadioButton radioButton1 = new JRadioButton("Option 1");
        JRadioButton radioButton2 = new JRadioButton("Option 2");

        buttonGroup.add(radioButton1);
        buttonGroup.add(radioButton2);

        radioButtonsPanel.add(radioButton1);
        radioButtonsPanel.add(radioButton2);

        // Create a JPanel to hold both left and right panels
        JPanel gameBoardPanel = new JPanel(new GridBagLayout());

        int gameBoardSize = 300; // Adjust the size as needed
        gameBoardPanel.setPreferredSize(new Dimension(gameBoardSize, gameBoardSize));

        int cellSize = gameBoardSize / 7;

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;

        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 7; j++) {
                JButton button = new JButton();
                button.setPreferredSize(new Dimension(cellSize, cellSize));

                gbc.gridx = i;
                gbc.gridy = j;

                gameBoardPanel.add(button, gbc);
            }
        }

        // Create a JPanel to hold both left and right panels
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(leftPanel, BorderLayout.WEST); // Add left panel to the left
        mainPanel.add(rightPanel, BorderLayout.CENTER); // Add right panel to the center

        // Create a JPanel for the bottom-left checkbox
        JPanel bottomLeftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bottomLeftPanel.add(checkBox);

        // Create a JPanel to hold everything
        JPanel containerPanel = new JPanel(new BorderLayout());
        containerPanel.add(mainPanel, BorderLayout.CENTER);
        containerPanel.add(bottomLeftPanel, BorderLayout.SOUTH);

        // Add the container panel to the content pane of the frame
        frame.getContentPane().add(containerPanel);

        // Set the default close operation
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Set the size of the frame
        frame.setSize(400, 400);

        // Make the frame visible
        frame.setVisible(true);
    }
}

